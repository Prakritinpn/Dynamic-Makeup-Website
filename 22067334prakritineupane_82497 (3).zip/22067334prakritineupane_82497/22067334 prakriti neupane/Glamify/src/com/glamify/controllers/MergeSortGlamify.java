/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.glamify.controllers;
import com.glamify.models.GlamifyModel;
import java.util.ArrayList;

/**
 *
 * @author Prakriti
 */
public class MergeSortGlamify {
    public MergeSortGlamify(){
    }
  
         public void sort(ArrayList<GlamifyModel> a, String sort){
        int datasize = a.size();
        if(datasize <=1){
            return;
        }
       
        int mid = datasize / 2;
        ArrayList<GlamifyModel> first = new ArrayList<>(a.subList(0, mid));
        ArrayList<GlamifyModel> second = new ArrayList<>(a.subList(mid, datasize));
       
        sort(first,sort);
        sort(second,sort);
        merge(first,second,a,sort);
           
    }

    private void merge(ArrayList<GlamifyModel> first, ArrayList<GlamifyModel> second, ArrayList<GlamifyModel> mainModels, String sort) {
        int firstCounter = 0;
        int secondCounter = 0;
        int mainArrayCounter = 0;
       
        while (firstCounter < first.size() && secondCounter < second.size()){
            switch (sort) {
                case "S.N." ->{
                  if((first.get(firstCounter)).getSerial_number()< (second.get(secondCounter).getSerial_number()))
                  {
                     mainModels.set(mainArrayCounter,first.get(firstCounter));
                     firstCounter++;
                  }else{
                      mainModels.set(mainArrayCounter,second.get(secondCounter));
                     secondCounter++;
                  }
                }
                 case "Product" ->{
                  if((first.get(firstCounter)).getProduct().compareTo((second.get(secondCounter).getProduct())) <= 0)
                  {
                     mainModels.set(mainArrayCounter,first.get(firstCounter));
                     firstCounter++;
                  }else{
                      mainModels.set(mainArrayCounter,second.get(secondCounter));
                     secondCounter++;
                  }
                }
                case "Shade" ->{
                  if((first.get(firstCounter)).getShade().compareTo((second.get(secondCounter).getShade())) <= 0)
                  {
                     mainModels.set(mainArrayCounter,first.get(firstCounter));
                     firstCounter++;
                  }else{
                      mainModels.set(mainArrayCounter,second.get(secondCounter));
                     secondCounter++;
                  }
                }
                case "Price(NPR)" ->{
                  if((first.get(firstCounter)).getPrice()< (second.get(secondCounter).getPrice()))
                  {
                     mainModels.set(mainArrayCounter,first.get(firstCounter));
                     firstCounter++;
                  }else{
                      mainModels.set(mainArrayCounter,second.get(secondCounter));
                     secondCounter++;
                  }
                }
                case "Skin Type" ->{
                  if((first.get(firstCounter)).getSkin_type().compareTo((second.get(secondCounter).getSkin_type())) <= 0)
                  {
                     mainModels.set(mainArrayCounter,first.get(firstCounter));
                     firstCounter++;
                  }else{
                      mainModels.set(mainArrayCounter,second.get(secondCounter));
                     secondCounter++;
                  }
                }
                case "Country" ->{
                  if((first.get(firstCounter)).getCountry().compareTo((second.get(secondCounter).getCountry())) <= 0)
                  {
                     mainModels.set(mainArrayCounter,first.get(firstCounter));
                     firstCounter++;
                  }else{
                      mainModels.set(mainArrayCounter,second.get(secondCounter));
                     secondCounter++;
                  }
                }
                case "Purchase Date" ->{
                  if((first.get(firstCounter)).getPurchase_date().compareTo((second.get(secondCounter).getPurchase_date())) <= 0)
                  {
                     mainModels.set(mainArrayCounter,first.get(firstCounter));
                     firstCounter++;
                  }else{
                      mainModels.set(mainArrayCounter,second.get(secondCounter));
                     secondCounter++;
                  }
                }
                
                case "Rating(5)" ->{
                  if((first.get(firstCounter)).getRating()< (second.get(secondCounter).getRating()))
                  {
                     mainModels.set(mainArrayCounter,first.get(firstCounter));
                     firstCounter++;
                  }else{
                      mainModels.set(mainArrayCounter,second.get(secondCounter));
                     secondCounter++;
                  }
                }
                default -> {
                    return;
                }
            }
             mainArrayCounter++;
        }
           while (firstCounter < first.size()){
               mainModels.set(mainArrayCounter,first.get(firstCounter));
                     firstCounter++;
                     mainArrayCounter++;
           }
           
           while (secondCounter < second.size()){
               mainModels.set(mainArrayCounter,second.get(secondCounter));
                     secondCounter++;
                     mainArrayCounter++;
           }
        }
}
