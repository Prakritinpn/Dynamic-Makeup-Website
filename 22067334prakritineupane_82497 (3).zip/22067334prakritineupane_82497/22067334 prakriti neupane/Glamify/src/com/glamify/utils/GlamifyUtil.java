/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.glamify.utils;

/**
 *
 * @author Prakriti
 */
public class GlamifyUtil {
    public static final String SEARCH_FOUND = "The search is found successfully!";
    public static final String INVALID_VALUE = "PLease enter valid alphabet values.";
    public static final String INVALID_INPUT = "PLease enter valid NUMERIC VALUES";
    public static final String INVALID = "PLease enter valid numeric values";
    
   
}
