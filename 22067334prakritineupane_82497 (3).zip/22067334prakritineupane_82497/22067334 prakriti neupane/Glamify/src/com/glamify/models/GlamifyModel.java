/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.glamify.models;

/**
 *
 * @author Prakriti
 */
public class GlamifyModel {
    int serial_number;
    String product;
    String brand;
    String shade;
    int price;
    String skin_type;
    String country;
    String purchase_date;
    int rating;

    public GlamifyModel(int serial_number, String product, String brand, String shade, int price, String skin_type, String country, String purchase_date, int rating) {
        this.serial_number = serial_number;
        this.product = product;
        this.brand = brand;
        this.shade = shade;
        this.price = price;
        this.skin_type = skin_type;
        this.country = country;
        this.purchase_date = purchase_date;
        this.rating = rating;
    }

    public int getSerial_number() {
        return serial_number;
    }

    public void setSerial_number(int serial_number) {
        this.serial_number = serial_number;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getShade() {
        return shade;
    }

    public void setShade(String shade) {
        this.shade = shade;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getSkin_type() {
        return skin_type;
    }

    public void setSkin_type(String skin_type) {
        this.skin_type = skin_type;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPurchase_date() {
        return purchase_date;
    }

    public void setPurchase_date(String purchase_date) {
        this.purchase_date = purchase_date;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
    

  
}

    
